__**Implemented:**__

- Extension to edit the dashboard background picture (available only on localhost:8080)
- Extension to get the data about the alerts related to the dashboard (works anywhere on internet)

__**In progress**__



**__TODO:__**

- Extension for which you get a guide for each page
- Extensions for which someone can leave notes about a page for other administrators
- Extensions that logs website issues
- 
