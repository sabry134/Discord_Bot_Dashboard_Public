kubectl delete pods --all
kubectl delete services --all
kubectl delete deployment --all