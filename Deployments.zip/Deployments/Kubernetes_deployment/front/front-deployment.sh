kubectl apply -f service.yaml
kubectl apply -f deployment.yaml
kubectl get service discord-front-service